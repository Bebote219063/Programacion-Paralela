# Práctica 1.3: Reduce en MPI con OpenMP

**Equipo 5** — Programación Paralela

## Integrantes (orden alfabético por primer apellido)
- Cortes Corona Jonathan Manuel
- Lara Jiménez Pablo César
- Martínez Delgado Miguel Ángel

## Descripción

Programa híbrido MPI + OpenMP que realiza operaciones aritméticas elemento a elemento
y reducciones colectivas sobre arreglos dinámicos distribuidos entre procesos MPI,
bajo un esquema maestro-esclavo. Cada proceso trabaja únicamente con su sección del
arreglo y usa OpenMP para repartir el trabajo entre los núcleos del nodo.

Cada nodo genera su propio archivo de log (`log_equipo_[NOMBRE_PC]_nodo_[RANK].txt`)
donde se registra todo lo que imprime en pantalla.

## Contenido

| Archivo | Descripción |
|---|---|
| `reduce_mpi.cpp` | Código fuente completo: clase `OperacionesArreglos`, clase `Registro`, menú de 12 opciones. |
| `Makefile` | Compilación y atajos de ejecución. |
| `hostfile` | Distribución de procesos entre los 3 nodos del clúster. |
| `pruebas/` | Salidas y logs de las ejecuciones realizadas. |

## Clase OperacionesArreglos

| Método | Función |
|---|---|
| `crearArregloMPI(n)` | Reserva con `new[]` la sección local de A, B y C. |
| `llenarSecuencial()` | Valores deterministas según el rank (permite validar las reducciones). |
| `llenarAleatorio()` | Valores aleatorios de 1 a 1,000,000; semilla por nodo con `srand(time+rank)`. |
| `operacionElemento(op)` | Suma, resta, multiplicación y cuadrado con `#pragma omp parallel for`. |
| `sumaLocal()` | Reducción local con `reduction(+:s)`. |
| `maxLocal()` | Reducción local con `reduction(max:m)`. |
| `minLocal()` | Reducción local con `reduction(min:m)`. |

## Esquema híbrido de dos niveles

- **Nivel 1 (OpenMP):** cada nodo reduce su sección local con cláusulas
  `reduction(+:…)`, `reduction(max:…)` y `reduction(min:…)`.
- **Nivel 2 (MPI):** los resultados locales se consolidan con `MPI_Reduce`
  (solo al nodo 0) y con `MPI_Allreduce` (a todos los nodos). El programa ejecuta y
  cronometra ambas variantes para poder compararlas.

## Versiones de comunicación implementadas

1. **Punto a punto:** `MPI_Send` / `MPI_Recv` para recolectar los resultados parciales.
2. **Colectiva de datos:** `MPI_Gather` para la misma recolección.
3. **Colectiva de reducción:** `MPI_Reduce` y `MPI_Allreduce` en las operaciones 8 a 11.

Las opciones 2 a 5 ejecutan y cronometran las versiones 1 y 2 en la misma corrida,
mostrando ambos tiempos para la tabla comparativa.

## Compilación

```bash
make
```
o manualmente:
```bash
mpic++ -fopenmp -O2 reduce_mpi.cpp -o reduce_mpi
```

Requisitos: `openmpi-bin`, `libopenmpi-dev`, `build-essential`.
```bash
sudo apt install -y build-essential openmpi-bin libopenmpi-dev
```

## Ejecución

El tamaño del arreglo global se pasa como argumento (por omisión 40). Si no es
divisible entre el número de procesos, el programa lo ajusta al múltiplo superior.

### Local (1 maestro + 4 trabajadores en una máquina)
```bash
mpirun -np 5 ./reduce_mpi 40          # primera ejecución: salida detallada
mpirun -np 5 ./reduce_mpi 4000000     # segunda ejecución: solo tiempos
```
Atajos: `make run40` y `make run4m`.

### Distribuida (clúster de 3 computadoras)
```bash
mpirun --hostfile hostfile -np 5 ./reduce_mpi 40
mpirun --hostfile hostfile -np 5 ./reduce_mpi 4000000
```
Atajos: `make dist40` y `make dist4m`.

El `hostfile` reparte los 5 procesos así: 2 en nodo1, 2 en nodo2 y 1 en nodo3.

## Menú (12 opciones)

El nodo maestro muestra el menú y difunde la opción elegida con `MPI_Bcast`.

```
 1. Crear arreglos          7. Llenar aleatorio
 2. Sumar arreglos          8. Sumatoria
 3. Restar arreglos         9. Promedio
 4. Multiplicar arreglos   10. Máximo
 5. Cuadrado de un arreglo 11. Mínimo
 6. Llenar secuencial      12. Salir
```

Orden sugerido para la demostración: `1` → `6` (o `7`) → `2` → `8` → `9` → `10` → `11` → `12`.

## Formato de los mensajes

```
[Equipo: nodo1] [Proceso MPI: 2] [Hilo OpenMP: 1] [Posicion: 15] [Operacion: Llenar secuencial] [Valor: A=16 B=32]
```

Con 40 elementos el detalle elemento a elemento está activo. Con 4,000,000 se desactiva
automáticamente (umbral: 1000 elementos) para no degradar el rendimiento, y solo se
muestran los tiempos de `MPI_Wtime()`.

## Verificación de resultados

Con llenado secuencial y N = 40, el arreglo A contiene 1..40, por lo que:

| Operación | Resultado esperado |
|---|---|
| Sumatoria | 820 |
| Promedio | 20.5 |
| Máximo | 40 |
| Mínimo | 1 |

Esto permite validar analíticamente que las reducciones son correctas.

## Notas técnicas

- **Arreglos dinámicos:** se usa exclusivamente `new[]` / `delete[]`. No se utiliza
  `vector`, `std::vector`, `ArrayList` ni estructuras equivalentes.
- **Aleatorios seguros entre hilos:** se usa `srand`/`rand` para obtener una semilla
  base distinta por nodo (combinando el tiempo y el rank). Como el estado interno de
  `rand()` es global y no es seguro cuando varios hilos lo llaman a la vez, cada hilo
  deriva de esa semilla su propio estado y genera con él, evitando condiciones de carrera.
- **Logs:** cada nodo cierra su archivo de log de forma segura antes de `MPI_Finalize()`.
